# Indian Food Nutrition Database
# Based on Indian Food Composition Tables (IFCT) - NIN Hyderabad
# Values per standard serving size

INDIAN_FOODS = {
    # South Indian Breakfast
    "idli": {
        "serving": "2 pieces (100g)",
        "calories": 156,
        "protein": 4.5,
        "carbs": 32,
        "fat": 0.4,
        "fiber": 1.2
    },
    "dosa": {
        "serving": "1 medium (120g)",
        "calories": 168,
        "protein": 4.2,
        "carbs": 28,
        "fat": 4.5,
        "fiber": 1.5
    },
    "masala dosa": {
        "serving": "1 piece with filling (180g)",
        "calories": 296,
        "protein": 6.2,
        "carbs": 42,
        "fat": 11,
        "fiber": 3.2
    },
    "uttapam": {
        "serving": "1 medium (150g)",
        "calories": 210,
        "protein": 5.5,
        "carbs": 38,
        "fat": 4,
        "fiber": 2.5
    },
    "upma": {
        "serving": "1 cup (200g)",
        "calories": 245,
        "protein": 5.8,
        "carbs": 38,
        "fat": 8,
        "fiber": 2.8
    },
    "pongal": {
        "serving": "1 cup (200g)",
        "calories": 280,
        "protein": 7,
        "carbs": 42,
        "fat": 9,
        "fiber": 1.5
    },
    "ven pongal": {
        "serving": "1 cup (200g)",
        "calories": 280,
        "protein": 7,
        "carbs": 42,
        "fat": 9,
        "fiber": 1.5
    },
    "medu vada": {
        "serving": "2 pieces (80g)",
        "calories": 298,
        "protein": 8.5,
        "carbs": 24,
        "fat": 18,
        "fiber": 3.2
    },
    "vada": {
        "serving": "2 pieces (80g)",
        "calories": 298,
        "protein": 8.5,
        "carbs": 24,
        "fat": 18,
        "fiber": 3.2
    },
    "poori": {
        "serving": "2 pieces (60g)",
        "calories": 198,
        "protein": 4.2,
        "carbs": 28,
        "fat": 8,
        "fiber": 1.2
    },
    "appam": {
        "serving": "2 pieces (100g)",
        "calories": 148,
        "protein": 3.2,
        "carbs": 28,
        "fat": 2.5,
        "fiber": 0.8
    },
    
    # Accompaniments
    "sambar": {
        "serving": "1 cup (200ml)",
        "calories": 130,
        "protein": 6.5,
        "carbs": 18,
        "fat": 4,
        "fiber": 4.5
    },
    "rasam": {
        "serving": "1 cup (200ml)",
        "calories": 52,
        "protein": 2,
        "carbs": 8,
        "fat": 1.5,
        "fiber": 1.2
    },
    "coconut chutney": {
        "serving": "2 tbsp (30g)",
        "calories": 65,
        "protein": 1,
        "carbs": 3,
        "fat": 5.5,
        "fiber": 1.5
    },
    "tomato chutney": {
        "serving": "2 tbsp (30g)",
        "calories": 35,
        "protein": 0.8,
        "carbs": 5,
        "fat": 1.5,
        "fiber": 0.8
    },
    "curd": {
        "serving": "1 cup (200g)",
        "calories": 120,
        "protein": 7,
        "carbs": 9,
        "fat": 6,
        "fiber": 0
    },
    "yogurt": {
        "serving": "1 cup (200g)",
        "calories": 120,
        "protein": 7,
        "carbs": 9,
        "fat": 6,
        "fiber": 0
    },
    "raita": {
        "serving": "1 cup (200g)",
        "calories": 135,
        "protein": 6.5,
        "carbs": 12,
        "fat": 6.5,
        "fiber": 1
    },
    
    # Rice Dishes
    "plain rice": {
        "serving": "1 cup cooked (200g)",
        "calories": 260,
        "protein": 5.2,
        "carbs": 56,
        "fat": 0.5,
        "fiber": 0.8
    },
    "rice": {
        "serving": "1 cup cooked (200g)",
        "calories": 260,
        "protein": 5.2,
        "carbs": 56,
        "fat": 0.5,
        "fiber": 0.8
    },
    "steamed rice": {
        "serving": "1 cup cooked (200g)",
        "calories": 260,
        "protein": 5.2,
        "carbs": 56,
        "fat": 0.5,
        "fiber": 0.8
    },
    "biryani": {
        "serving": "1 plate (300g)",
        "calories": 490,
        "protein": 18,
        "carbs": 62,
        "fat": 18,
        "fiber": 2.5
    },
    "veg biryani": {
        "serving": "1 plate (300g)",
        "calories": 420,
        "protein": 10,
        "carbs": 65,
        "fat": 14,
        "fiber": 4
    },
    "chicken biryani": {
        "serving": "1 plate (350g)",
        "calories": 550,
        "protein": 25,
        "carbs": 62,
        "fat": 22,
        "fiber": 2
    },
    "mutton biryani": {
        "serving": "1 plate (350g)",
        "calories": 620,
        "protein": 28,
        "carbs": 60,
        "fat": 28,
        "fiber": 2
    },
    "pulao": {
        "serving": "1 cup (200g)",
        "calories": 285,
        "protein": 6,
        "carbs": 48,
        "fat": 8,
        "fiber": 2
    },
    "lemon rice": {
        "serving": "1 cup (200g)",
        "calories": 295,
        "protein": 5.5,
        "carbs": 52,
        "fat": 7.5,
        "fiber": 1.5
    },
    "curd rice": {
        "serving": "1 cup (250g)",
        "calories": 285,
        "protein": 8,
        "carbs": 48,
        "fat": 6.5,
        "fiber": 1
    },
    "tamarind rice": {
        "serving": "1 cup (200g)",
        "calories": 310,
        "protein": 5.5,
        "carbs": 54,
        "fat": 8,
        "fiber": 2
    },
    "coconut rice": {
        "serving": "1 cup (200g)",
        "calories": 340,
        "protein": 6,
        "carbs": 50,
        "fat": 13,
        "fiber": 3
    },
    
    # Rotis and Breads
    "chapati": {
        "serving": "2 pieces (60g)",
        "calories": 180,
        "protein": 6,
        "carbs": 32,
        "fat": 3.5,
        "fiber": 3.8
    },
    "roti": {
        "serving": "2 pieces (60g)",
        "calories": 180,
        "protein": 6,
        "carbs": 32,
        "fat": 3.5,
        "fiber": 3.8
    },
    "phulka": {
        "serving": "2 pieces (50g)",
        "calories": 150,
        "protein": 5,
        "carbs": 28,
        "fat": 2,
        "fiber": 3.2
    },
    "paratha": {
        "serving": "1 piece (80g)",
        "calories": 260,
        "protein": 5.5,
        "carbs": 36,
        "fat": 10,
        "fiber": 2.5
    },
    "aloo paratha": {
        "serving": "1 piece (120g)",
        "calories": 320,
        "protein": 7,
        "carbs": 45,
        "fat": 12,
        "fiber": 3.5
    },
    "naan": {
        "serving": "1 piece (90g)",
        "calories": 262,
        "protein": 8.5,
        "carbs": 45,
        "fat": 5,
        "fiber": 2
    },
    "butter naan": {
        "serving": "1 piece (100g)",
        "calories": 310,
        "protein": 8.5,
        "carbs": 45,
        "fat": 10,
        "fiber": 2
    },
    "garlic naan": {
        "serving": "1 piece (100g)",
        "calories": 295,
        "protein": 9,
        "carbs": 46,
        "fat": 8,
        "fiber": 2.2
    },
    "kulcha": {
        "serving": "1 piece (90g)",
        "calories": 275,
        "protein": 7.5,
        "carbs": 42,
        "fat": 8,
        "fiber": 2
    },
    "bhatura": {
        "serving": "1 piece (80g)",
        "calories": 295,
        "protein": 6,
        "carbs": 38,
        "fat": 13,
        "fiber": 1.5
    },
    
    # Curries - Vegetarian
    "dal": {
        "serving": "1 cup (200g)",
        "calories": 180,
        "protein": 12,
        "carbs": 26,
        "fat": 4,
        "fiber": 8
    },
    "dal tadka": {
        "serving": "1 cup (200g)",
        "calories": 210,
        "protein": 12,
        "carbs": 26,
        "fat": 7,
        "fiber": 8
    },
    "dal fry": {
        "serving": "1 cup (200g)",
        "calories": 220,
        "protein": 12,
        "carbs": 26,
        "fat": 8,
        "fiber": 8
    },
    "chana masala": {
        "serving": "1 cup (200g)",
        "calories": 280,
        "protein": 12,
        "carbs": 38,
        "fat": 9,
        "fiber": 10
    },
    "chole": {
        "serving": "1 cup (200g)",
        "calories": 280,
        "protein": 12,
        "carbs": 38,
        "fat": 9,
        "fiber": 10
    },
    "rajma": {
        "serving": "1 cup (200g)",
        "calories": 245,
        "protein": 14,
        "carbs": 35,
        "fat": 5,
        "fiber": 12
    },
    "paneer butter masala": {
        "serving": "1 cup (200g)",
        "calories": 420,
        "protein": 16,
        "carbs": 18,
        "fat": 32,
        "fiber": 2.5
    },
    "palak paneer": {
        "serving": "1 cup (200g)",
        "calories": 320,
        "protein": 15,
        "carbs": 12,
        "fat": 24,
        "fiber": 4
    },
    "matar paneer": {
        "serving": "1 cup (200g)",
        "calories": 340,
        "protein": 15,
        "carbs": 18,
        "fat": 24,
        "fiber": 5
    },
    "shahi paneer": {
        "serving": "1 cup (200g)",
        "calories": 450,
        "protein": 16,
        "carbs": 16,
        "fat": 36,
        "fiber": 2
    },
    "kadai paneer": {
        "serving": "1 cup (200g)",
        "calories": 380,
        "protein": 15,
        "carbs": 14,
        "fat": 30,
        "fiber": 3
    },
    "aloo gobi": {
        "serving": "1 cup (200g)",
        "calories": 180,
        "protein": 5,
        "carbs": 24,
        "fat": 8,
        "fiber": 5
    },
    "aloo matar": {
        "serving": "1 cup (200g)",
        "calories": 195,
        "protein": 6,
        "carbs": 28,
        "fat": 7,
        "fiber": 5.5
    },
    "bhindi masala": {
        "serving": "1 cup (150g)",
        "calories": 145,
        "protein": 4,
        "carbs": 12,
        "fat": 9,
        "fiber": 5
    },
    "baingan bharta": {
        "serving": "1 cup (200g)",
        "calories": 165,
        "protein": 4,
        "carbs": 14,
        "fat": 11,
        "fiber": 6
    },
    "mixed vegetable curry": {
        "serving": "1 cup (200g)",
        "calories": 175,
        "protein": 5,
        "carbs": 18,
        "fat": 9,
        "fiber": 5
    },
    "veg kurma": {
        "serving": "1 cup (200g)",
        "calories": 245,
        "protein": 6,
        "carbs": 22,
        "fat": 15,
        "fiber": 4.5
    },
    "malai kofta": {
        "serving": "1 cup (200g)",
        "calories": 410,
        "protein": 10,
        "carbs": 28,
        "fat": 30,
        "fiber": 3
    },
    "kootu": {
        "serving": "1 cup (200g)",
        "calories": 165,
        "protein": 8,
        "carbs": 22,
        "fat": 5,
        "fiber": 6
    },
    "avial": {
        "serving": "1 cup (200g)",
        "calories": 185,
        "protein": 5,
        "carbs": 16,
        "fat": 12,
        "fiber": 5
    },
    "poriyal": {
        "serving": "1 cup (150g)",
        "calories": 120,
        "protein": 4,
        "carbs": 12,
        "fat": 7,
        "fiber": 4
    },
    "thoran": {
        "serving": "1 cup (150g)",
        "calories": 145,
        "protein": 4.5,
        "carbs": 10,
        "fat": 10,
        "fiber": 5
    },
    
    # Non-Vegetarian Curries
    "chicken curry": {
        "serving": "1 cup (200g)",
        "calories": 320,
        "protein": 28,
        "carbs": 10,
        "fat": 18,
        "fiber": 2
    },
    "butter chicken": {
        "serving": "1 cup (200g)",
        "calories": 438,
        "protein": 28,
        "carbs": 14,
        "fat": 30,
        "fiber": 2
    },
    "chicken tikka masala": {
        "serving": "1 cup (200g)",
        "calories": 385,
        "protein": 30,
        "carbs": 12,
        "fat": 24,
        "fiber": 2.5
    },
    "kadai chicken": {
        "serving": "1 cup (200g)",
        "calories": 340,
        "protein": 28,
        "carbs": 10,
        "fat": 20,
        "fiber": 2.5
    },
    "mutton curry": {
        "serving": "1 cup (200g)",
        "calories": 410,
        "protein": 32,
        "carbs": 8,
        "fat": 28,
        "fiber": 1.5
    },
    "mutton rogan josh": {
        "serving": "1 cup (200g)",
        "calories": 420,
        "protein": 32,
        "carbs": 10,
        "fat": 28,
        "fiber": 2
    },
    "fish curry": {
        "serving": "1 cup (200g)",
        "calories": 265,
        "protein": 26,
        "carbs": 8,
        "fat": 14,
        "fiber": 1.5
    },
    "prawn curry": {
        "serving": "1 cup (200g)",
        "calories": 245,
        "protein": 24,
        "carbs": 10,
        "fat": 12,
        "fiber": 2
    },
    "egg curry": {
        "serving": "1 cup with 2 eggs (200g)",
        "calories": 295,
        "protein": 16,
        "carbs": 10,
        "fat": 22,
        "fiber": 2
    },
    "keema": {
        "serving": "1 cup (200g)",
        "calories": 385,
        "protein": 28,
        "carbs": 12,
        "fat": 26,
        "fiber": 2.5
    },
    
    # Snacks
    "samosa": {
        "serving": "2 pieces (100g)",
        "calories": 308,
        "protein": 5,
        "carbs": 32,
        "fat": 18,
        "fiber": 2.5
    },
    "pakora": {
        "serving": "5 pieces (100g)",
        "calories": 285,
        "protein": 6,
        "carbs": 28,
        "fat": 16,
        "fiber": 3
    },
    "bhajji": {
        "serving": "5 pieces (100g)",
        "calories": 285,
        "protein": 6,
        "carbs": 28,
        "fat": 16,
        "fiber": 3
    },
    "cutlet": {
        "serving": "2 pieces (80g)",
        "calories": 220,
        "protein": 6,
        "carbs": 24,
        "fat": 11,
        "fiber": 2
    },
    "bonda": {
        "serving": "2 pieces (80g)",
        "calories": 245,
        "protein": 4.5,
        "carbs": 28,
        "fat": 13,
        "fiber": 2
    },
    "bajji": {
        "serving": "3 pieces (90g)",
        "calories": 265,
        "protein": 4,
        "carbs": 30,
        "fat": 14,
        "fiber": 2.5
    },
    "murukku": {
        "serving": "50g",
        "calories": 265,
        "protein": 5,
        "carbs": 32,
        "fat": 13,
        "fiber": 2
    },
    "mixture": {
        "serving": "50g",
        "calories": 275,
        "protein": 6,
        "carbs": 28,
        "fat": 15,
        "fiber": 3
    },
    "kachori": {
        "serving": "2 pieces (80g)",
        "calories": 320,
        "protein": 6,
        "carbs": 34,
        "fat": 18,
        "fiber": 3
    },
    "pav bhaji": {
        "serving": "1 plate (300g)",
        "calories": 450,
        "protein": 12,
        "carbs": 58,
        "fat": 18,
        "fiber": 6
    },
    
    # Street Food / Chaat
    "pani puri": {
        "serving": "6 pieces (120g)",
        "calories": 185,
        "protein": 4,
        "carbs": 32,
        "fat": 5,
        "fiber": 2.5
    },
    "golgappa": {
        "serving": "6 pieces (120g)",
        "calories": 185,
        "protein": 4,
        "carbs": 32,
        "fat": 5,
        "fiber": 2.5
    },
    "bhel puri": {
        "serving": "1 plate (150g)",
        "calories": 245,
        "protein": 5.5,
        "carbs": 38,
        "fat": 8,
        "fiber": 4
    },
    "sev puri": {
        "serving": "6 pieces (150g)",
        "calories": 285,
        "protein": 5,
        "carbs": 36,
        "fat": 13,
        "fiber": 3.5
    },
    "dahi puri": {
        "serving": "6 pieces (180g)",
        "calories": 265,
        "protein": 6,
        "carbs": 38,
        "fat": 10,
        "fiber": 3
    },
    "aloo tikki": {
        "serving": "2 pieces (100g)",
        "calories": 220,
        "protein": 4.5,
        "carbs": 32,
        "fat": 9,
        "fiber": 3
    },
    "papdi chaat": {
        "serving": "1 plate (150g)",
        "calories": 310,
        "protein": 7,
        "carbs": 42,
        "fat": 13,
        "fiber": 4
    },
    "vada pav": {
        "serving": "1 piece (150g)",
        "calories": 290,
        "protein": 7,
        "carbs": 42,
        "fat": 10,
        "fiber": 3
    },
    
    # Sweets
    "gulab jamun": {
        "serving": "2 pieces (80g)",
        "calories": 302,
        "protein": 4,
        "carbs": 45,
        "fat": 12,
        "fiber": 0.5
    },
    "rasgulla": {
        "serving": "2 pieces (80g)",
        "calories": 186,
        "protein": 4,
        "carbs": 38,
        "fat": 2,
        "fiber": 0
    },
    "jalebi": {
        "serving": "3 pieces (75g)",
        "calories": 285,
        "protein": 2.5,
        "carbs": 48,
        "fat": 10,
        "fiber": 0.5
    },
    "ladoo": {
        "serving": "2 pieces (60g)",
        "calories": 295,
        "protein": 5,
        "carbs": 38,
        "fat": 14,
        "fiber": 2
    },
    "barfi": {
        "serving": "2 pieces (50g)",
        "calories": 215,
        "protein": 4,
        "carbs": 28,
        "fat": 10,
        "fiber": 0.5
    },
    "kheer": {
        "serving": "1 cup (200g)",
        "calories": 295,
        "protein": 8,
        "carbs": 42,
        "fat": 11,
        "fiber": 0.5
    },
    "payasam": {
        "serving": "1 cup (200g)",
        "calories": 310,
        "protein": 7,
        "carbs": 48,
        "fat": 10,
        "fiber": 1
    },
    "halwa": {
        "serving": "100g",
        "calories": 365,
        "protein": 4,
        "carbs": 52,
        "fat": 16,
        "fiber": 2
    },
    "gajar halwa": {
        "serving": "100g",
        "calories": 295,
        "protein": 5,
        "carbs": 38,
        "fat": 14,
        "fiber": 3
    },
    "kesari": {
        "serving": "100g",
        "calories": 345,
        "protein": 3,
        "carbs": 52,
        "fat": 14,
        "fiber": 0.5
    },
    "mysore pak": {
        "serving": "2 pieces (50g)",
        "calories": 285,
        "protein": 4,
        "carbs": 28,
        "fat": 18,
        "fiber": 1.5
    },
    
    # Beverages
    "chai": {
        "serving": "1 cup (150ml)",
        "calories": 72,
        "protein": 2.5,
        "carbs": 10,
        "fat": 2.5,
        "fiber": 0
    },
    "tea": {
        "serving": "1 cup (150ml)",
        "calories": 72,
        "protein": 2.5,
        "carbs": 10,
        "fat": 2.5,
        "fiber": 0
    },
    "filter coffee": {
        "serving": "1 cup (150ml)",
        "calories": 85,
        "protein": 2.5,
        "carbs": 10,
        "fat": 3.5,
        "fiber": 0
    },
    "masala chai": {
        "serving": "1 cup (150ml)",
        "calories": 78,
        "protein": 2.5,
        "carbs": 11,
        "fat": 2.5,
        "fiber": 0.2
    },
    "lassi": {
        "serving": "1 glass (250ml)",
        "calories": 185,
        "protein": 6,
        "carbs": 28,
        "fat": 5,
        "fiber": 0
    },
    "sweet lassi": {
        "serving": "1 glass (250ml)",
        "calories": 210,
        "protein": 6,
        "carbs": 35,
        "fat": 5,
        "fiber": 0
    },
    "mango lassi": {
        "serving": "1 glass (250ml)",
        "calories": 235,
        "protein": 6,
        "carbs": 42,
        "fat": 5,
        "fiber": 1
    },
    "buttermilk": {
        "serving": "1 glass (250ml)",
        "calories": 62,
        "protein": 4,
        "carbs": 6,
        "fat": 2.5,
        "fiber": 0
    },
    "chaas": {
        "serving": "1 glass (250ml)",
        "calories": 62,
        "protein": 4,
        "carbs": 6,
        "fat": 2.5,
        "fiber": 0
    },
    "badam milk": {
        "serving": "1 glass (250ml)",
        "calories": 215,
        "protein": 8,
        "carbs": 28,
        "fat": 8,
        "fiber": 1.5
    },
    "jaljeera": {
        "serving": "1 glass (250ml)",
        "calories": 35,
        "protein": 0.5,
        "carbs": 8,
        "fat": 0,
        "fiber": 0.5
    },
    
    # Eggs
    "boiled egg": {
        "serving": "2 eggs (100g)",
        "calories": 155,
        "protein": 13,
        "carbs": 1,
        "fat": 11,
        "fiber": 0
    },
    "fried egg": {
        "serving": "2 eggs (110g)",
        "calories": 196,
        "protein": 13,
        "carbs": 1,
        "fat": 15,
        "fiber": 0
    },
    "egg bhurji": {
        "serving": "2 eggs (120g)",
        "calories": 215,
        "protein": 14,
        "carbs": 4,
        "fat": 16,
        "fiber": 0.5
    },
    "omelette": {
        "serving": "2 eggs (120g)",
        "calories": 190,
        "protein": 13,
        "carbs": 2,
        "fat": 14,
        "fiber": 0.5
    },
    
    # Tandoori / Grilled
    "tandoori chicken": {
        "serving": "2 pieces (200g)",
        "calories": 265,
        "protein": 35,
        "carbs": 6,
        "fat": 11,
        "fiber": 1
    },
    "chicken tikka": {
        "serving": "6 pieces (150g)",
        "calories": 235,
        "protein": 30,
        "carbs": 5,
        "fat": 10,
        "fiber": 0.5
    },
    "seekh kebab": {
        "serving": "2 pieces (100g)",
        "calories": 265,
        "protein": 18,
        "carbs": 6,
        "fat": 19,
        "fiber": 1
    },
    "paneer tikka": {
        "serving": "6 pieces (150g)",
        "calories": 320,
        "protein": 18,
        "carbs": 8,
        "fat": 24,
        "fiber": 2
    },
    
    # Common additions
    "pickle": {
        "serving": "1 tbsp (15g)",
        "calories": 25,
        "protein": 0.3,
        "carbs": 2,
        "fat": 2,
        "fiber": 0.5
    },
    "papad": {
        "serving": "2 pieces (20g)",
        "calories": 72,
        "protein": 4,
        "carbs": 10,
        "fat": 2,
        "fiber": 1.5
    },
    "ghee": {
        "serving": "1 tbsp (15g)",
        "calories": 135,
        "protein": 0,
        "carbs": 0,
        "fat": 15,
        "fiber": 0
    },
    
    # Fruits (common Indian)
    "banana": {
        "serving": "1 medium (120g)",
        "calories": 105,
        "protein": 1.3,
        "carbs": 27,
        "fat": 0.4,
        "fiber": 3
    },
    "mango": {
        "serving": "1 cup sliced (165g)",
        "calories": 99,
        "protein": 1.4,
        "carbs": 25,
        "fat": 0.6,
        "fiber": 2.6
    },
    "papaya": {
        "serving": "1 cup (145g)",
        "calories": 62,
        "protein": 0.7,
        "carbs": 16,
        "fat": 0.4,
        "fiber": 2.5
    },
    "apple": {
        "serving": "1 medium (180g)",
        "calories": 95,
        "protein": 0.5,
        "carbs": 25,
        "fat": 0.3,
        "fiber": 4.4
    },
    "orange": {
        "serving": "1 medium (130g)",
        "calories": 62,
        "protein": 1.2,
        "carbs": 15,
        "fat": 0.2,
        "fiber": 3.1
    },
    "watermelon": {
        "serving": "1 cup (150g)",
        "calories": 46,
        "protein": 0.9,
        "carbs": 11,
        "fat": 0.2,
        "fiber": 0.6
    },
    "pomegranate": {
        "serving": "1 cup seeds (175g)",
        "calories": 144,
        "protein": 2.9,
        "carbs": 33,
        "fat": 2,
        "fiber": 7
    },
    "grapes": {
        "serving": "1 cup (150g)",
        "calories": 104,
        "protein": 1.1,
        "carbs": 27,
        "fat": 0.2,
        "fiber": 1.4
    },
    "guava": {
        "serving": "1 medium (100g)",
        "calories": 68,
        "protein": 2.6,
        "carbs": 14,
        "fat": 1,
        "fiber": 5.4
    },
    "chikoo": {
        "serving": "1 medium (100g)",
        "calories": 83,
        "protein": 0.4,
        "carbs": 20,
        "fat": 1.1,
        "fiber": 5.3
    },
    "sapota": {
        "serving": "1 medium (100g)",
        "calories": 83,
        "protein": 0.4,
        "carbs": 20,
        "fat": 1.1,
        "fiber": 5.3
    }
}

def find_food(query: str) -> dict | None:
    """Find food in database with fuzzy matching"""
    query = query.lower().strip()
    
    # Direct match
    if query in INDIAN_FOODS:
        return {"name": query, **INDIAN_FOODS[query]}
    
    # Partial match
    for food_name, nutrition in INDIAN_FOODS.items():
        if query in food_name or food_name in query:
            return {"name": food_name, **nutrition}
    
    return None

def get_all_foods() -> list:
    """Return list of all food names"""
    return list(INDIAN_FOODS.keys())
