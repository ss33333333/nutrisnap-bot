"""
NutriSnap - Telegram Nutrition Tracker Bot
Snap your Indian meals, get instant nutrition info
"""

import os
import sqlite3
import logging
from datetime import datetime, timedelta
from io import BytesIO
import json
import re

import google.generativeai as genai
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from PIL import Image

from indian_food_db import INDIAN_FOODS, find_food

# ============== CONFIG ==============
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

# ============== LOGGING ==============
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============== DATABASE ==============
def init_db():
    """Initialize SQLite database"""
    conn = sqlite3.connect("nutrition_logs.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS meals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            foods TEXT NOT NULL,
            calories REAL,
            protein REAL,
            carbs REAL,
            fat REAL,
            fiber REAL
        )
    """)
    conn.commit()
    conn.close()

def log_meal(user_id: int, foods: list, totals: dict):
    """Log a meal to database"""
    conn = sqlite3.connect("nutrition_logs.db")
    c = conn.cursor()
    c.execute("""
        INSERT INTO meals (user_id, foods, calories, protein, carbs, fat, fiber)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        user_id,
        json.dumps(foods),
        totals.get("calories", 0),
        totals.get("protein", 0),
        totals.get("carbs", 0),
        totals.get("fat", 0),
        totals.get("fiber", 0)
    ))
    conn.commit()
    conn.close()

def get_meals_since(user_id: int, since: datetime) -> list:
    """Get meals since a given datetime"""
    conn = sqlite3.connect("nutrition_logs.db")
    c = conn.cursor()
    c.execute("""
        SELECT timestamp, foods, calories, protein, carbs, fat, fiber
        FROM meals
        WHERE user_id = ? AND timestamp >= ?
        ORDER BY timestamp DESC
    """, (user_id, since.isoformat()))
    rows = c.fetchall()
    conn.close()
    return rows

# ============== GEMINI SETUP ==============
def setup_gemini():
    """Configure Gemini API"""
    genai.configure(api_key=GEMINI_API_KEY)
    return genai.GenerativeModel("gemini-1.5-flash")

# ============== FOOD ANALYSIS ==============
ANALYSIS_PROMPT = """You are a nutrition assistant specialized in Indian food.

Analyze this image of food and identify ALL items visible in the meal.

IMPORTANT RULES:
1. List ONLY the food items you can clearly see
2. For each item, estimate the portion size (e.g., "2 idlis", "1 cup rice", "1 bowl sambar")
3. Focus on Indian food names (use local names like "idli", "dosa", "sambar", "rasam", etc.)
4. Include accompaniments like chutneys, pickles, papad
5. If you see a thali/plate with multiple items, list each separately

OUTPUT FORMAT (strict JSON):
{
    "foods": [
        {"name": "food name in lowercase", "quantity": "amount with unit"},
        {"name": "another food", "quantity": "amount"}
    ],
    "confidence": "high/medium/low",
    "notes": "any relevant notes about the meal"
}

If you cannot identify the food or if the image doesn't show food, respond with:
{"foods": [], "confidence": "none", "notes": "reason"}
"""

async def analyze_food_image(model, image_bytes: bytes) -> dict:
    """Use Gemini to analyze food image"""
    try:
        img = Image.open(BytesIO(image_bytes))
        
        response = model.generate_content([ANALYSIS_PROMPT, img])
        text = response.text
        
        # Extract JSON from response
        json_match = re.search(r'\{[\s\S]*\}', text)
        if json_match:
            return json.loads(json_match.group())
        
        return {"foods": [], "confidence": "none", "notes": "Could not parse response"}
    
    except Exception as e:
        logger.error(f"Gemini analysis error: {e}")
        return {"foods": [], "confidence": "none", "notes": str(e)}

def calculate_nutrition(foods: list) -> tuple[list, dict]:
    """Calculate nutrition from identified foods"""
    detailed_foods = []
    totals = {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
    
    for item in foods:
        name = item.get("name", "").lower()
        quantity = item.get("quantity", "1 serving")
        
        # Find in database
        food_data = find_food(name)
        
        if food_data:
            # Parse quantity multiplier (simplified)
            multiplier = 1.0
            qty_lower = quantity.lower()
            
            # Extract number from quantity
            num_match = re.search(r'(\d+(?:\.\d+)?)', qty_lower)
            if num_match:
                num = float(num_match.group(1))
                # Adjust multiplier based on common patterns
                if "half" in qty_lower or "1/2" in qty_lower:
                    multiplier = 0.5
                elif "quarter" in qty_lower or "1/4" in qty_lower:
                    multiplier = 0.25
                elif num <= 10:  # Reasonable serving count
                    # For items typically counted (idli, dosa, roti)
                    if any(x in name for x in ["idli", "dosa", "roti", "chapati", "paratha", "vada", "poori", "naan"]):
                        base_count = 2 if "idli" in name or "roti" in name or "chapati" in name or "poori" in name else 1
                        multiplier = num / base_count
                    else:
                        multiplier = num
            
            # Calculate nutrition with multiplier
            food_entry = {
                "name": food_data["name"],
                "quantity": quantity,
                "serving": food_data["serving"],
                "calories": round(food_data["calories"] * multiplier, 1),
                "protein": round(food_data["protein"] * multiplier, 1),
                "carbs": round(food_data["carbs"] * multiplier, 1),
                "fat": round(food_data["fat"] * multiplier, 1),
                "fiber": round(food_data["fiber"] * multiplier, 1),
                "matched": True
            }
        else:
            # Food not in database - estimate
            food_entry = {
                "name": name,
                "quantity": quantity,
                "serving": "estimated",
                "calories": 150,  # Default estimate
                "protein": 5,
                "carbs": 20,
                "fat": 5,
                "fiber": 2,
                "matched": False
            }
        
        detailed_foods.append(food_entry)
        
        # Add to totals
        for key in totals:
            totals[key] += food_entry.get(key, 0)
    
    # Round totals
    totals = {k: round(v, 1) for k, v in totals.items()}
    
    return detailed_foods, totals

# ============== BOT HANDLERS ==============
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send welcome message"""
    welcome = """🍛 *NutriSnap* - Your Indian Food Nutrition Tracker

📸 *How to use:*
Just send me a photo of your meal and I'll:
• Identify the dishes
• Calculate calories, protein, carbs, fat & fiber
• Log it automatically

📊 *Commands:*
/today - Today's nutrition summary
/week - This week's summary  
/stats - Your all-time stats
/history - Recent meal history
/help - Show this message

Let's track your nutrition! Send your first meal photo 🍽️"""
    
    await update.message.reply_text(welcome, parse_mode="Markdown")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help"""
    await start(update, context)

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process food photo"""
    user_id = update.effective_user.id
    
    # Send processing message
    processing_msg = await update.message.reply_text("🔍 Analyzing your meal...")
    
    try:
        # Get photo (largest size)
        photo = update.message.photo[-1]
        file = await context.bot.get_file(photo.file_id)
        
        # Download image
        image_bytes = await file.download_as_bytearray()
        
        # Analyze with Gemini
        model = setup_gemini()
        analysis = await analyze_food_image(model, bytes(image_bytes))
        
        if not analysis.get("foods"):
            await processing_msg.edit_text(
                "❌ Couldn't identify food in this image.\n\n"
                f"Reason: {analysis.get('notes', 'Unknown')}\n\n"
                "Tips:\n"
                "• Make sure food is clearly visible\n"
                "• Good lighting helps\n"
                "• Try a closer shot"
            )
            return
        
        # Calculate nutrition
        detailed_foods, totals = calculate_nutrition(analysis["foods"])
        
        # Log to database
        log_meal(user_id, detailed_foods, totals)
        
        # Format response
        response = "✅ *Meal Logged!*\n\n"
        response += "🍽️ *Items identified:*\n"
        
        for food in detailed_foods:
            match_icon = "✓" if food.get("matched") else "?"
            response += f"  {match_icon} {food['name'].title()} ({food['quantity']})\n"
            response += f"     {food['calories']} kcal | P:{food['protein']}g\n"
        
        response += f"\n📊 *Meal Totals:*\n"
        response += f"  🔥 Calories: *{totals['calories']}* kcal\n"
        response += f"  💪 Protein: *{totals['protein']}g*\n"
        response += f"  🍚 Carbs: *{totals['carbs']}g*\n"
        response += f"  🧈 Fat: *{totals['fat']}g*\n"
        response += f"  🌾 Fiber: *{totals['fiber']}g*\n"
        
        if analysis.get("confidence") == "low":
            response += "\n⚠️ _Low confidence - portions estimated_"
        
        unmatched = [f for f in detailed_foods if not f.get("matched")]
        if unmatched:
            response += f"\n\n_Note: {len(unmatched)} item(s) not in database, using estimates_"
        
        await processing_msg.edit_text(response, parse_mode="Markdown")
        
    except Exception as e:
        logger.error(f"Error processing photo: {e}")
        await processing_msg.edit_text(
            f"❌ Error processing image: {str(e)}\n\nPlease try again."
        )

async def today_summary(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show today's nutrition summary"""
    user_id = update.effective_user.id
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    meals = get_meals_since(user_id, today)
    
    if not meals:
        await update.message.reply_text(
            "📭 No meals logged today yet!\n\nSend a photo of your food to start tracking."
        )
        return
    
    totals = {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
    
    for meal in meals:
        totals["calories"] += meal[2] or 0
        totals["protein"] += meal[3] or 0
        totals["carbs"] += meal[4] or 0
        totals["fat"] += meal[5] or 0
        totals["fiber"] += meal[6] or 0
    
    # Round totals
    totals = {k: round(v, 1) for k, v in totals.items()}
    
    response = f"📊 *Today's Nutrition* ({len(meals)} meals)\n\n"
    response += f"🔥 Calories: *{totals['calories']}* kcal\n"
    response += f"💪 Protein: *{totals['protein']}g*\n"
    response += f"🍚 Carbs: *{totals['carbs']}g*\n"
    response += f"🧈 Fat: *{totals['fat']}g*\n"
    response += f"🌾 Fiber: *{totals['fiber']}g*\n"
    
    # Protein target reminder (based on your 75-85g goal)
    protein_remaining = max(0, 80 - totals['protein'])
    if protein_remaining > 0:
        response += f"\n🎯 _Need {protein_remaining:.0f}g more protein to hit 80g target_"
    else:
        response += f"\n✅ _Protein target achieved!_"
    
    await update.message.reply_text(response, parse_mode="Markdown")

async def week_summary(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show this week's summary"""
    user_id = update.effective_user.id
    week_ago = datetime.now() - timedelta(days=7)
    
    meals = get_meals_since(user_id, week_ago)
    
    if not meals:
        await update.message.reply_text(
            "📭 No meals logged this week!\n\nSend a photo of your food to start tracking."
        )
        return
    
    totals = {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
    
    for meal in meals:
        totals["calories"] += meal[2] or 0
        totals["protein"] += meal[3] or 0
        totals["carbs"] += meal[4] or 0
        totals["fat"] += meal[5] or 0
        totals["fiber"] += meal[6] or 0
    
    # Calculate averages
    days = 7
    avgs = {k: round(v / days, 1) for k, v in totals.items()}
    totals = {k: round(v, 1) for k, v in totals.items()}
    
    response = f"📊 *This Week's Nutrition* ({len(meals)} meals)\n\n"
    response += f"*Daily Averages:*\n"
    response += f"🔥 Calories: *{avgs['calories']}* kcal/day\n"
    response += f"💪 Protein: *{avgs['protein']}g*/day\n"
    response += f"🍚 Carbs: *{avgs['carbs']}g*/day\n"
    response += f"🧈 Fat: *{avgs['fat']}g*/day\n"
    response += f"🌾 Fiber: *{avgs['fiber']}g*/day\n"
    
    response += f"\n*Weekly Totals:*\n"
    response += f"🔥 {totals['calories']} kcal | 💪 {totals['protein']}g protein"
    
    await update.message.reply_text(response, parse_mode="Markdown")

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show all-time stats"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect("nutrition_logs.db")
    c = conn.cursor()
    
    # Get total meals and date range
    c.execute("""
        SELECT 
            COUNT(*),
            MIN(timestamp),
            MAX(timestamp),
            SUM(calories),
            SUM(protein),
            AVG(calories),
            AVG(protein)
        FROM meals
        WHERE user_id = ?
    """, (user_id,))
    
    row = c.fetchone()
    conn.close()
    
    if not row or not row[0]:
        await update.message.reply_text(
            "📭 No meals logged yet!\n\nSend a photo of your food to start tracking."
        )
        return
    
    total_meals = row[0]
    first_meal = row[1][:10] if row[1] else "N/A"
    last_meal = row[2][:10] if row[2] else "N/A"
    total_cals = round(row[3] or 0, 0)
    total_protein = round(row[4] or 0, 0)
    avg_cals = round(row[5] or 0, 0)
    avg_protein = round(row[6] or 0, 1)
    
    response = f"📈 *Your Nutrition Stats*\n\n"
    response += f"🍽️ Total meals logged: *{total_meals}*\n"
    response += f"📅 Tracking since: {first_meal}\n"
    response += f"📅 Last meal: {last_meal}\n\n"
    response += f"*Averages per meal:*\n"
    response += f"🔥 {avg_cals} kcal | 💪 {avg_protein}g protein\n\n"
    response += f"*All-time totals:*\n"
    response += f"🔥 {total_cals:,.0f} kcal consumed\n"
    response += f"💪 {total_protein:,.0f}g protein consumed"
    
    await update.message.reply_text(response, parse_mode="Markdown")

async def history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show recent meal history"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect("nutrition_logs.db")
    c = conn.cursor()
    c.execute("""
        SELECT timestamp, foods, calories, protein
        FROM meals
        WHERE user_id = ?
        ORDER BY timestamp DESC
        LIMIT 10
    """, (user_id,))
    rows = c.fetchall()
    conn.close()
    
    if not rows:
        await update.message.reply_text(
            "📭 No meals logged yet!\n\nSend a photo of your food to start tracking."
        )
        return
    
    response = "📜 *Recent Meals*\n\n"
    
    for row in rows:
        timestamp = row[0][:16].replace("T", " ")  # Format datetime
        foods = json.loads(row[1])
        food_names = ", ".join([f["name"].title() for f in foods[:3]])
        if len(foods) > 3:
            food_names += f" +{len(foods)-3} more"
        
        response += f"*{timestamp}*\n"
        response += f"  {food_names}\n"
        response += f"  🔥 {row[2]:.0f} kcal | 💪 {row[3]:.0f}g\n\n"
    
    await update.message.reply_text(response, parse_mode="Markdown")

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages - manual food entry"""
    text = update.message.text.lower().strip()
    
    # Check if it's a food item
    food = find_food(text)
    
    if food:
        user_id = update.effective_user.id
        detailed_foods = [{
            "name": food["name"],
            "quantity": "1 serving",
            "serving": food["serving"],
            "calories": food["calories"],
            "protein": food["protein"],
            "carbs": food["carbs"],
            "fat": food["fat"],
            "fiber": food["fiber"],
            "matched": True
        }]
        
        totals = {
            "calories": food["calories"],
            "protein": food["protein"],
            "carbs": food["carbs"],
            "fat": food["fat"],
            "fiber": food["fiber"]
        }
        
        log_meal(user_id, detailed_foods, totals)
        
        response = f"✅ *Logged: {food['name'].title()}*\n"
        response += f"📏 Serving: {food['serving']}\n\n"
        response += f"🔥 Calories: *{food['calories']}* kcal\n"
        response += f"💪 Protein: *{food['protein']}g*\n"
        response += f"🍚 Carbs: *{food['carbs']}g*\n"
        response += f"🧈 Fat: *{food['fat']}g*\n"
        response += f"🌾 Fiber: *{food['fiber']}g*"
        
        await update.message.reply_text(response, parse_mode="Markdown")
    else:
        await update.message.reply_text(
            "📸 Send me a photo of your meal to log it!\n\n"
            "Or type a food name like 'idli', 'dosa', 'biryani' to log manually.\n\n"
            "Commands: /today /week /stats /help"
        )

# ============== MAIN ==============
def main():
    """Start the bot"""
    # Validate env vars
    if not TELEGRAM_TOKEN:
        raise ValueError("TELEGRAM_TOKEN environment variable not set")
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY environment variable not set")
    
    # Initialize database
    init_db()
    
    # Create application
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Add handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("today", today_summary))
    app.add_handler(CommandHandler("week", week_summary))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("history", history))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    
    # Start polling
    logger.info("Bot starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
